import React from 'react';
import { Radio, Mountain, Signal, Battery, Mic2 } from 'lucide-react';

const RadioSection: React.FC = () => {
  return (
    <section id="radios" className="py-20 bg-white border-t border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-2 bg-orange-100 rounded-full mb-4">
             <Radio className="w-6 h-6 text-orange-600" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">RADIOS DE COMUNICACIÓN</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
             Suministro de radios de alta potencia para flotas de transporte. Comunicación confiable, clara y de largo alcance en zonas rurales y de relieve variable.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row items-center gap-12">
            
            <div className="w-full lg:w-1/2">
                <div className="bg-gray-900 rounded-2xl p-8 text-white shadow-2xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 bg-red-600 font-bold text-sm uppercase tracking-widest rounded-bl-xl">Alta Potencia</div>
                    <h3 className="text-3xl font-extrabold mb-1">YAESU FT-2980R</h3>
                    <p className="text-gray-400 mb-6 font-mono">VHF 80 WATTS - HEAVY DUTY</p>
                    
                    {/* Updated image to look like a vehicle mounted radio */}
                    <img 
                        src="https://images.unsplash.com/photo-1541414779316-956a5084c0d4?auto=format&fit=crop&q=80&w=600" 
                        alt="Equipo de Radio Comunicación Vehicular" 
                        className="rounded-lg mb-8 border-2 border-gray-700 w-full object-cover h-64 bg-black opacity-90"
                    />

                    <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="bg-gray-800 p-3 rounded-lg">
                            <span className="block text-gray-500 text-xs">Frecuencia</span>
                            <span className="font-bold">136 - 174 MHz</span>
                        </div>
                        <div className="bg-gray-800 p-3 rounded-lg">
                            <span className="block text-gray-500 text-xs">Potencia Salida</span>
                            <span className="font-bold text-red-400">80 Watts Reales</span>
                        </div>
                        <div className="bg-gray-800 p-3 rounded-lg">
                            <span className="block text-gray-500 text-xs">Marca</span>
                            <span className="font-bold">YAESU (Japón)</span>
                        </div>
                        <div className="bg-gray-800 p-3 rounded-lg">
                            <span className="block text-gray-500 text-xs">Garantía</span>
                            <span className="font-bold">1 Año Defectos</span>
                        </div>
                    </div>
                </div>
            </div>

            <div className="w-full lg:w-1/2 space-y-8">
                <div className="flex gap-4">
                    <div className="flex-shrink-0">
                        <Mountain className="w-8 h-8 text-orange-500" />
                    </div>
                    <div>
                        <h4 className="text-xl font-bold text-gray-900">Rango Extendido en Relieve</h4>
                        <p className="text-gray-600 mt-1">
                            Diseñado para topografías difíciles. Alcance estimado de <strong>30 a 35 km</strong> en terreno plano y <strong>15 a 25 km</strong> en zonas con relieve.
                        </p>
                    </div>
                </div>

                <div className="flex gap-4">
                    <div className="flex-shrink-0">
                        <Mic2 className="w-8 h-8 text-orange-500" />
                    </div>
                    <div>
                        <h4 className="text-xl font-bold text-gray-900">Kit Completo de Instalación</h4>
                        <p className="text-gray-600 mt-1">
                            Incluye micrófono original YAESU, soporte de montaje robusto, cable de alimentación y antena combo VHF modelo RUM-150 (base + varilla).
                        </p>
                    </div>
                </div>

                <div className="flex gap-4">
                    <div className="flex-shrink-0">
                        <Signal className="w-8 h-8 text-orange-500" />
                    </div>
                    <div>
                        <h4 className="text-xl font-bold text-gray-900">Sin Rentas Mensuales</h4>
                        <p className="text-gray-600 mt-1">
                            A diferencia del celular o GPS, la comunicación por radio no requiere pagos mensuales ni depende de torres celulares.
                        </p>
                    </div>
                </div>

                <div className="pt-4">
                    <a href="https://wa.me/59176618826?text=Me%20interesa%20cotizar%20equipos%20de%20radio%20YAESU" className="inline-block bg-orange-600 text-white px-8 py-3 rounded-lg font-bold hover:bg-orange-700 transition-colors shadow-lg">
                        Solicitar Cotización de Radios
                    </a>
                </div>
            </div>

        </div>
      </div>
    </section>
  );
};

export default RadioSection;