import React from 'react';
import { Droplets, TrendingDown, ShieldAlert } from 'lucide-react';

const FuelSection: React.FC = () => {
  return (
    <section id="combustible" className="py-20 bg-white border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
            
            <div className="w-full lg:w-1/2">
                <h2 className="text-3xl font-bold text-slate-900 mb-6">
                    Gestión de Combustible
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                    Optimice los costos operativos de su flota. Nuestro sistema de sensores avanzados permite una lectura precisa del nivel de combustible, ideal para maquinaria pesada y flotas de transporte.
                </p>
                
                <div className="space-y-6">
                    <div className="flex items-start gap-4">
                        <div className="p-3 bg-gray-50 rounded-lg text-slate-600">
                            <Droplets size={24} />
                        </div>
                        <div>
                            <h4 className="font-bold text-gray-900">Control de Litros Exactos</h4>
                            <p className="text-sm text-gray-500">Visualice el volumen actual de los tanques con alta precisión.</p>
                        </div>
                    </div>
                    <div className="flex items-start gap-4">
                        <div className="p-3 bg-gray-50 rounded-lg text-slate-600">
                            <ShieldAlert size={24} />
                        </div>
                        <div>
                            <h4 className="font-bold text-gray-900">Alertas de Robo (Ordeñe)</h4>
                            <p className="text-sm text-gray-500">Notificaciones instantáneas ante caídas bruscas de nivel.</p>
                        </div>
                    </div>
                </div>

                <div className="mt-8 p-4 bg-orange-50 border-l-4 border-orange-500 rounded-r-lg">
                    <p className="text-sm text-slate-700">
                        <strong>Nota:</strong> Este servicio requiere un estudio previo de la unidad y se trabaja bajo pedido específico.
                    </p>
                </div>
            </div>

            <div className="w-full lg:w-1/2 relative">
                 <div className="absolute -inset-4 bg-gray-200 rounded-full blur-3xl opacity-20"></div>
                 <img 
                    src="https://images.unsplash.com/photo-1529310399831-ed472b81d589?auto=format&fit=crop&q=80&w=600" 
                    alt="Maquinaria pesada construcción y combustible" 
                    className="relative rounded-2xl shadow-xl z-10 object-cover w-full h-[400px]"
                 />
            </div>

        </div>
      </div>
    </section>
  );
};

export default FuelSection;