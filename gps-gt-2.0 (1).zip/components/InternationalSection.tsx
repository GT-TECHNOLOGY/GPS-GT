import React from 'react';
import { Globe, Map, Signal } from 'lucide-react';

const InternationalSection: React.FC = () => {
  return (
    <section id="internacional" className="py-20 bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center gap-12">
          
          <div className="w-full md:w-1/2">
             <span className="inline-block py-1 px-3 rounded-full bg-blue-100 text-blue-800 text-xs font-bold tracking-wider uppercase mb-4">
                Servicio Premium
             </span>
             <h2 className="text-3xl md:text-5xl font-extrabold text-slate-900 mb-6 leading-tight">
                Logística Internacional <br/>
                <span className="text-blue-600">Sin Interrupciones</span>
             </h2>
             <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                Ideal para transporte pesado y logística de exportación. Nuestro servicio de <strong>Roaming Multi-Operador</strong> garantiza que sus activos permanezcan visibles al cruzar fronteras.
             </p>

             <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="p-4 bg-white rounded-xl shadow-sm border border-gray-100 hover:border-blue-200 transition-colors">
                    <Globe className="w-8 h-8 text-blue-500 mb-3" />
                    <h4 className="font-bold text-slate-800">Cobertura Continental</h4>
                    <p className="text-sm text-gray-500">Rastreo continuo en Sudamérica.</p>
                </div>
                <div className="p-4 bg-white rounded-xl shadow-sm border border-gray-100 hover:border-blue-200 transition-colors">
                    <Signal className="w-8 h-8 text-blue-500 mb-3" />
                    <h4 className="font-bold text-slate-800">Auto-Switching</h4>
                    <p className="text-sm text-gray-500">Conexión automática a la mejor red disponible.</p>
                </div>
             </div>
          </div>

          <div className="w-full md:w-1/2 relative">
             <div className="absolute inset-0 bg-blue-600 rounded-2xl transform rotate-3 opacity-10"></div>
             <div className="relative bg-slate-900 rounded-2xl p-1 overflow-hidden shadow-2xl">
                <img 
                    src="https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&q=80&w=800" 
                    alt="Mapa global logística y transporte" 
                    className="rounded-xl opacity-80 w-full object-cover h-[400px]"
                />
                <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black to-transparent">
                    <div className="flex items-center gap-3 text-white">
                        <Map className="w-6 h-6 text-teal-400" />
                        <span className="font-mono text-sm">ESTADO: EN RUTA / ROAMING ACTIVO</span>
                    </div>
                </div>
             </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default InternationalSection;