import React from 'react';
import { MessageCircle, Phone } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <footer id="contacto" className="bg-white pt-16 pb-8 border-t border-gray-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        
        <h2 className="text-3xl font-extrabold text-gray-900 mb-4">
          ¿Listo para proteger tu patrimonio?
        </h2>
        <p className="text-xl text-gray-600 mb-10">
            Solicita tu instalación ahora mismo. Rastreo confiable y soporte real.
        </p>

        <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-3xl p-8 md:p-12 text-white shadow-2xl mb-12 transform hover:-translate-y-1 transition-transform duration-300">
            <p className="text-blue-200 uppercase tracking-widest font-bold text-sm mb-2">Contáctanos vía WhatsApp</p>
            <div className="flex flex-col md:flex-row items-center justify-center gap-6">
                <div className="flex items-center gap-3">
                    <MessageCircle className="w-10 h-10" />
                    <span className="text-4xl md:text-5xl font-bold">(+591) 76618826</span>
                </div>
            </div>
            <div className="mt-8">
                <a 
                    href="https://wa.me/59176618826" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block bg-white text-blue-700 hover:bg-gray-100 font-bold py-4 px-10 rounded-full shadow-lg transition-all text-lg"
                >
                    Enviar Mensaje Ahora
                </a>
            </div>
        </div>

        <div className="text-gray-400 text-sm">
          <p className="flex items-center justify-center gap-2 mb-2">
            <Phone size={16} /> Soporte técnico garantizado
          </p>
          <p>&copy; {new Date().getFullYear()} GPS-GT Seguridad y Tecnología. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Contact;