import React from 'react';
import { Video, Eye, Truck, HardDrive } from 'lucide-react';

const CameraSection: React.FC = () => {
  return (
    <section id="camaras" className="py-24 bg-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-teal-400 font-bold tracking-widest uppercase text-sm">Seguridad Industrial</span>
          <h2 className="mt-2 text-4xl font-bold text-white">Cámaras Vehiculares MDVR</h2>
          <p className="mt-4 text-slate-400 text-lg">
            Sistema de videovigilancia móvil para flotas pesadas y uso industrial. Grabación simultánea multicanal para evidencia irrefutable.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
           <div className="grid grid-cols-2 gap-4">
              <div className="relative group">
                 <img src="https://images.unsplash.com/photo-1468818519844-64bc429824de?auto=format&fit=crop&q=80&w=300" alt="Cámara Frontal Camino" className="rounded-xl shadow-lg border border-slate-700 h-40 w-full object-cover" />
                 <div className="absolute bottom-2 left-2 bg-black/60 px-2 py-1 rounded text-xs font-bold">Adelante</div>
              </div>
              <div className="relative group mt-8">
                 <img src="https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&q=80&w=300" alt="Cámara Cabina Interior" className="rounded-xl shadow-lg border border-slate-700 h-40 w-full object-cover" />
                 <div className="absolute bottom-2 left-2 bg-black/60 px-2 py-1 rounded text-xs font-bold">Cabina</div>
              </div>
              <div className="relative group">
                 <img src="https://images.unsplash.com/photo-1502877338535-edcfeb6f37c9?auto=format&fit=crop&q=80&w=300" alt="Cámara Trasera Retroceso" className="rounded-xl shadow-lg border border-slate-700 h-40 w-full object-cover" />
                 <div className="absolute bottom-2 left-2 bg-black/60 px-2 py-1 rounded text-xs font-bold">Atrás</div>
              </div>
              <div className="relative group mt-8">
                 <img src="https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&q=80&w=300" alt="MDVR System Hardware" className="rounded-xl shadow-lg border border-slate-700 h-40 w-full object-cover" />
                 <div className="absolute bottom-2 left-2 bg-black/60 px-2 py-1 rounded text-xs font-bold">Sistema MDVR</div>
              </div>
           </div>

           <div className="space-y-8">
              <div className="flex gap-5">
                <div className="flex-shrink-0 w-14 h-14 rounded-full bg-teal-500/20 flex items-center justify-center border border-teal-500/50">
                  <Eye className="text-teal-400 w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Cobertura Total (3 Canales)</h3>
                  <p className="text-slate-400 mt-2">
                    <strong className="text-white">1. Frontal:</strong> Evidencia de accidentes y estado del camino.<br/>
                    <strong className="text-white">2. Cabina:</strong> Monitoreo de conducta del conductor y fatiga.<br/>
                    <strong className="text-white">3. Trasera:</strong> Seguridad en retroceso y supervisión de carga.
                  </p>
                </div>
              </div>

              <div className="flex gap-5">
                <div className="flex-shrink-0 w-14 h-14 rounded-full bg-blue-500/20 flex items-center justify-center border border-blue-500/50">
                  <Video className="text-blue-400 w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Transmisión en Tiempo Real</h3>
                  <p className="text-slate-400 mt-2">
                    Acceda al video en vivo desde nuestra plataforma web o aplicación móvil a través de la red 4G integrada.
                  </p>
                </div>
              </div>

              <div className="flex gap-5">
                <div className="flex-shrink-0 w-14 h-14 rounded-full bg-purple-500/20 flex items-center justify-center border border-purple-500/50">
                  <HardDrive className="text-purple-400 w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Almacenamiento Seguro</h3>
                  <p className="text-slate-400 mt-2">
                    Soporte para discos duros y tarjetas SD de alta capacidad. Grabación en bucle a prueba de vibraciones extremas.
                  </p>
                </div>
              </div>
              
              <div className="pt-6">
                 <a href="https://wa.me/59176618826?text=Me%20interesa%20el%20sistema%20de%20camaras%20industriales" className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-slate-900 bg-teal-400 hover:bg-teal-500 transition-colors">
                    Cotizar Sistema de Cámaras
                 </a>
              </div>
           </div>
        </div>

      </div>
    </section>
  );
};

export default CameraSection;