import React from 'react';
import { BatteryCharging, Anchor, Unlock, Lock, Power } from 'lucide-react';

const Extras: React.FC = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900">SOLUCIONES ADICIONALES</h2>
          <p className="text-gray-600 mt-2">Flexibilidad para cada necesidad</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          
          {/* GPS Portatil */}
          <div className="bg-white rounded-2xl p-8 shadow-xl border-t-4 border-purple-500 flex flex-col md:flex-row gap-8 items-center">
            <div className="w-full md:w-1/2">
                <img src="https://images.unsplash.com/photo-1599139343750-f3b7d15967ee?auto=format&fit=crop&q=80&w=400" alt="Paquete o activo rastreable GPS Portátil" className="rounded-lg shadow-sm object-cover w-full h-64" />
            </div>
            <div className="w-full md:w-1/2">
                <h3 className="text-2xl font-extrabold text-gray-900 mb-4">GPS PORTÁTIL</h3>
                <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-xs font-bold uppercase">Opción Multiusos</span>
                <ul className="mt-6 space-y-3">
                    <li className="flex items-center gap-2 text-gray-700">
                        <BatteryCharging className="text-purple-500 w-5 h-5" /> Recargable (Hasta 15 días de uso)
                    </li>
                    <li className="flex items-center gap-2 text-gray-700">
                        <Anchor className="text-purple-500 w-5 h-5" /> Base imantada fuerte
                    </li>
                    <li className="flex items-center gap-2 text-gray-700">
                        <Unlock className="text-purple-500 w-5 h-5" /> No requiere instalación
                    </li>
                </ul>
                <p className="mt-4 text-sm text-gray-500 italic">Ideal para seguimientos temporales, mercancía o vehículos de terceros.</p>
            </div>
          </div>

          {/* Boton de Corte */}
          <div className="bg-white rounded-2xl p-8 shadow-xl border-t-4 border-red-500 flex flex-col md:flex-row gap-8 items-center">
            <div className="w-full md:w-1/2 order-2 md:order-1">
                 <h3 className="text-2xl font-extrabold text-gray-900 mb-4">BOTÓN DE CORTE</h3>
                 <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-xs font-bold uppercase">Anti-Asalto</span>
                 <p className="mt-4 text-gray-700">
                     Botón oculto estratégico. El vehículo <strong>no arrancará</strong> sin antes presionar este dispositivo.
                 </p>
                 <ul className="mt-6 space-y-3">
                    <li className="flex items-center gap-2 text-gray-700">
                        <Lock className="text-red-500 w-5 h-5" /> Protección extra frente a robos
                    </li>
                    <li className="flex items-center gap-2 text-gray-700">
                        <Power className="text-red-500 w-5 h-5" /> Bloqueo físico independiente
                    </li>
                </ul>
            </div>
            <div className="w-full md:w-1/2 order-1 md:order-2">
                <img src="https://images.unsplash.com/photo-1618423771880-2c6769d96c42?auto=format&fit=crop&q=80&w=400" alt="Interior vehículo tablero seguro" className="rounded-lg shadow-sm object-cover w-full h-64" />
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Extras;