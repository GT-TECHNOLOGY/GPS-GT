import React from 'react';
import { CheckCircle2, Zap, Globe, ShoppingBag } from 'lucide-react';

const PricingSection: React.FC = () => {
  return (
    <section id="planes" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 sm:text-4xl">PLANES Y PRECIOS</h2>
          <p className="mt-4 text-lg text-gray-600">Alternativas flexibles para cada necesidad</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Plan 1: Servicio Nacional (Annual Rental) */}
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden border-2 border-blue-100 transform transition-all hover:-translate-y-1 hover:shadow-xl relative flex flex-col">
            <div className="h-40 overflow-hidden relative">
                <img 
                    src="https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&q=80&w=600" 
                    alt="Flota de vehículos comerciales vans" 
                    className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-white to-transparent opacity-80"></div>
                <div className="absolute top-4 left-0 bg-blue-600 text-white py-1 px-4 rounded-r-full text-xs font-bold uppercase shadow-md">
                  Más Popular
                </div>
            </div>
            
            <div className="p-8 text-center pt-2 flex-grow">
                <h3 className="text-xl font-bold text-blue-900 mb-2">SERVICIO NACIONAL</h3>
                <p className="text-sm text-gray-500 mb-6">(Modalidad Alquiler Anual)</p>
                
                <div className="flex justify-center items-baseline mb-2">
                    <span className="text-4xl font-extrabold text-slate-900">Bs. 1.100</span>
                </div>
                <p className="text-sm text-blue-600 font-semibold mb-6">1er. año (Instalación incluida)</p>
                
                <div className="border-t border-gray-100 pt-4 mb-6">
                     <p className="text-sm text-gray-500">Renovación Anual</p>
                     <span className="text-2xl font-bold text-slate-700">Bs. 850</span>
                </div>

                <a href="https://wa.me/59176618826?text=Quiero%20el%20Servicio%20Nacional%20Anual" className="block w-full bg-blue-600 text-white font-bold py-3 rounded-lg hover:bg-blue-700 transition-colors">
                    LO QUIERO
                </a>
            </div>
            <div className="bg-gray-50 p-8 mt-auto">
                <ul className="space-y-3 text-sm text-gray-700">
                    <li className="flex items-start gap-2"><CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" /> Equipo en modalidad alquiler</li>
                    <li className="flex items-start gap-2"><CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" /> Garantía activa mientras mantengas la suscripción</li>
                    <li className="flex items-start gap-2"><CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" /> Todas las funciones incluidas</li>
                    <li className="flex items-start gap-2"><CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" /> Sin mensualidades</li>
                </ul>
            </div>
          </div>

           {/* Plan 2: Venta Nacional (Purchase) */}
           <div className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-200 transform transition-all hover:-translate-y-1 hover:shadow-xl flex flex-col">
            <div className="h-40 overflow-hidden relative">
                 <img 
                    src="https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&q=80&w=600" 
                    alt="Hardware electrónico GPS circuitos" 
                    className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-white to-transparent opacity-80"></div>
                 <div className="absolute bottom-0 left-0 right-0 flex justify-center transform translate-y-1/2">
                    <div className="p-3 bg-purple-100 rounded-full border-4 border-white">
                        <ShoppingBag className="w-6 h-6 text-purple-600" />
                    </div>
                </div>
            </div>

            <div className="p-8 text-center pt-8 flex-grow">
                <h3 className="text-xl font-bold text-purple-900 mb-2">VENTA NACIONAL</h3>
                <p className="text-sm text-gray-500 mb-6">(Compra de equipo)</p>
                
                <div className="flex justify-center items-baseline mb-2">
                    <span className="text-4xl font-extrabold text-slate-900">Bs. 1.450</span>
                </div>
                <p className="text-sm text-purple-600 font-semibold mb-6">Pago único por el equipo</p>
                
                <div className="border-t border-gray-100 pt-4 mb-6">
                     <p className="text-sm text-gray-500">Mantenimiento Plataforma (2do año)</p>
                     <span className="text-2xl font-bold text-slate-700">Bs. 300</span>
                </div>

                <a href="https://wa.me/59176618826?text=Quiero%20comprar%20el%20equipo%20GPS" className="block w-full bg-purple-600 text-white font-bold py-3 rounded-lg hover:bg-purple-700 transition-colors">
                    LO QUIERO
                </a>
            </div>
            <div className="bg-gray-50 p-8 mt-auto">
                <ul className="space-y-3 text-sm text-gray-700">
                    <li className="flex items-start gap-2"><CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" /> Equipo completamente tuyo</li>
                    <li className="flex items-start gap-2"><CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" /> Garantía real de 3 años</li>
                    <li className="flex items-start gap-2"><CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" /> Todas las funciones incluidas desde el día 1</li>
                </ul>
            </div>
          </div>

          {/* Plan 3: Servicio Internacional */}
          <div className="bg-slate-900 text-white rounded-2xl shadow-xl overflow-hidden border border-slate-700 transform transition-all hover:-translate-y-1 hover:shadow-2xl flex flex-col">
            <div className="h-40 overflow-hidden relative">
                 <img 
                    src="https://images.unsplash.com/photo-1506306486966-98cc721b6d10?auto=format&fit=crop&q=80&w=600" 
                    alt="Transporte internacional carga pesada carretera" 
                    className="w-full h-full object-cover opacity-80"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent"></div>
                 <div className="absolute bottom-0 left-0 right-0 flex justify-center transform translate-y-1/2">
                    <div className="p-3 bg-slate-800 rounded-full border-4 border-slate-900">
                        <Globe className="w-6 h-6 text-teal-400" />
                    </div>
                </div>
            </div>

            <div className="p-8 text-center pt-8 flex-grow">
                <h3 className="text-xl font-bold text-teal-400 mb-2">SERVICIO INTERNACIONAL</h3>
                <p className="text-sm text-slate-400 mb-6">(Modalidad Anual)</p>
                
                <div className="flex justify-center items-baseline mb-2">
                    <span className="text-4xl font-extrabold">Bs. 1.750</span>
                </div>
                <p className="text-sm text-teal-400 font-semibold mb-6">1er. año (Cobertura Total)</p>
                
                <div className="border-t border-slate-700 pt-4 mb-6">
                     <p className="text-sm text-slate-400">Renovación Anual</p>
                     <span className="text-2xl font-bold text-white">Bs. 1.500</span>
                </div>

                <a href="https://wa.me/59176618826?text=Quiero%20el%20Plan%20Internacional" className="block w-full bg-teal-500 text-slate-900 font-bold py-3 rounded-lg hover:bg-teal-400 transition-colors">
                    LO QUIERO
                </a>
            </div>
            <div className="bg-slate-800 p-8 border-t border-slate-700 mt-auto">
                <ul className="space-y-3 text-sm text-slate-300">
                    <li className="flex items-start gap-2"><CheckCircle2 className="w-5 h-5 text-teal-400 flex-shrink-0" /> Disponible para Chile, Paraguay, Brasil, Uruguay, Argentina, Bolivia, Perú y más.</li>
                    <li className="flex items-start gap-2"><CheckCircle2 className="w-5 h-5 text-teal-400 flex-shrink-0" /> Garantía activa con suscripción</li>
                    <li className="flex items-start gap-2"><CheckCircle2 className="w-5 h-5 text-teal-400 flex-shrink-0" /> Roaming Multi-Operador</li>
                </ul>
            </div>
          </div>

        </div>

        <div className="mt-12 text-center bg-blue-50 p-6 rounded-xl border border-blue-100">
             <p className="text-slate-700 font-medium">
                Instalación en todo Bolivia. Viáticos (transporte, alimentación y hospedaje) se cotizan según ciudad y cantidad de unidades.
             </p>
        </div>

      </div>
    </section>
  );
};

export default PricingSection;