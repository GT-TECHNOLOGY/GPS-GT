import React from 'react';
import { Globe2, Clock, CheckCircle } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="hero" className="relative bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32 flex flex-col-reverse lg:flex-row items-center">
        
        <div className="w-full lg:w-1/2 text-center lg:text-left mt-10 lg:mt-0 z-20">
          <div className="inline-flex items-center gap-2 bg-teal-500/20 px-4 py-2 rounded-full mb-6 border border-teal-400/30 backdrop-blur-sm">
             <CheckCircle className="w-5 h-5 text-teal-400" />
             <span className="text-sm font-bold text-teal-100 uppercase tracking-wide">Garantía Real de 3 Años</span>
          </div>
          <h1 className="text-4xl lg:text-6xl font-extrabold tracking-tight leading-tight mb-6">
            Rastreo GPS confiable con <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-blue-400">
              Instalación Hoy
            </span>
          </h1>
          <p className="text-xl lg:text-2xl text-slate-300 mb-8 font-light">
            Control total de tu vehículo o flota sin mensualidades. Soporte técnico en <strong>menos de 15 minutos</strong> y plataforma App/Web 24/7.
          </p>
          
          <div className="flex flex-wrap justify-center lg:justify-start gap-6 mb-8 text-sm font-medium text-slate-400">
            <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-400" /> Soporte &lt;15 min
            </div>
            <div className="flex items-center gap-2">
                <Globe2 className="w-5 h-5 text-blue-400" /> Instalación Nacional
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
            <a 
              href="https://wa.me/59176618826?text=Quiero%20cotizar%20un%20GPS"
              target="_blank"
              className="px-8 py-4 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-700 transition-colors shadow-lg shadow-blue-600/30"
            >
              Cotizar por WhatsApp
            </a>
            <a 
              href="#planes"
              className="px-8 py-4 bg-white/10 backdrop-blur-md text-white border border-white/20 rounded-lg font-bold hover:bg-white/20 transition-colors"
            >
              Ver Planes y Precios
            </a>
          </div>
        </div>

        <div className="w-full lg:w-1/2 flex justify-center relative">
          {/* Decorative blobs */}
          <div className="absolute top-10 right-10 w-72 h-72 bg-blue-600 rounded-full mix-blend-screen filter blur-[100px] opacity-40 animate-blob"></div>
          <div className="absolute bottom-0 left-10 w-72 h-72 bg-teal-500 rounded-full mix-blend-screen filter blur-[100px] opacity-30 animate-blob animation-delay-2000"></div>
          
          <img 
            src="https://images.unsplash.com/photo-1516738901171-8eb4fc13bd20?auto=format&fit=crop&q=80&w=1000" 
            alt="Dashboard de Navegación GPS en auto moderno" 
            className="relative z-10 rounded-2xl shadow-2xl border-4 border-slate-700/50 object-cover h-[400px] w-full max-w-lg"
          />
        </div>
      </div>
    </section>
  );
};

export default Hero;