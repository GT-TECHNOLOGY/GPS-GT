import React from 'react';
import { HelpCircle, ChevronRight } from 'lucide-react';

const FAQ: React.FC = () => {
  const faqs = [
    {
      q: "¿La instalación afecta mi vehículo?",
      a: "No; la instalación es profesional, segura y no invasiva."
    },
    {
      q: "¿Hay pagos mensuales?",
      a: "No; nuestros planes principales son de pago anual único."
    },
    {
      q: "¿Puedo apagar el motor desde el celular?",
      a: "Sí, cuenta con función de paro de motor remoto con asesoría para uso seguro."
    },
    {
      q: "¿Qué pasa si vendo o cambio de vehículo?",
      a: "Podemos trasladar el equipo a su nueva unidad o pasar la cuenta al nuevo dueño."
    },
    {
      q: "¿Tengo cobertura en otros países?",
      a: "Sí, adquiriendo el Plan Internacional tienes cobertura en toda la región."
    },
    {
      q: "¿Cuánto tarda la instalación?",
      a: "Aproximadamente 60 a 90 minutos por vehículo."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">PREGUNTAS FRECUENTES</h2>
        </div>

        <div className="space-y-4">
          {faqs.map((item, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-6 border border-gray-200 hover:border-blue-300 transition-colors cursor-default">
              <div className="flex items-start gap-4">
                <HelpCircle className="w-6 h-6 text-blue-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">{item.q}</h3>
                  <p className="text-gray-600 flex items-center gap-2">
                     <ChevronRight className="w-4 h-4 text-blue-400" /> {item.a}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;