import React from 'react';
import { Star } from 'lucide-react';

const Testimonials: React.FC = () => {
  const reviews = [
    {
      name: "Alex Lorenzo Surubi",
      location: "Santa Cruz",
      image: "https://picsum.photos/100/100?random=11",
      text: "Pues el producto para mi es excelente, una buena herramienta para monitorear los vehículos móviles, la herramienta fácil de utilizar por el celular respecto a dar con la ubicación exacta de la movilidad. Respecto al soporte, muy bien, rápida la asistencia.",
      rating: 5
    },
    {
      name: "Jose Pablo",
      location: "Chiquitania",
      image: "https://picsum.photos/100/100?random=12",
      text: "Buena atención y bonita aplicacion pero falta adicional control de combustible para maquinaria amarilla.",
      rating: 4
    },
    {
      name: "Mariano Mendez R.",
      location: "Sucre",
      image: "https://picsum.photos/100/100?random=13",
      text: "El servicio fue excelente. Yo lo usé para el vehículo de trabajo en la empresa y tienes funciones muy cómodas prácticas y algo muy importante es que el soporte técnico y atención es muy bueno! Recomendable.",
      rating: 5
    }
  ];

  return (
    <section className="py-20 bg-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-teal-400 font-bold tracking-widest text-sm uppercase">Testimonios y Autoridad</span>
          <h2 className="mt-2 text-3xl font-bold text-white sm:text-4xl">LO QUE DICEN NUESTROS CLIENTES</h2>
          <div className="mt-8 inline-flex items-center bg-slate-800 rounded-full px-6 py-3 border border-slate-700">
            <span className="text-2xl font-bold text-white mr-2">+100</span>
            <span className="text-slate-400 text-sm">unidades activas en 7 ciudades</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <div key={index} className="bg-slate-800 rounded-xl p-8 border border-slate-700 relative hover:bg-slate-750 transition-colors">
              <div className="absolute -top-6 left-1/2 transform -translate-x-1/2">
                <img src={review.image} alt={review.name} className="w-12 h-12 rounded-full border-2 border-blue-500" />
              </div>
              <div className="mt-6 text-center">
                <h3 className="font-bold text-lg text-white">{review.name}</h3>
                <p className="text-sm text-blue-400 mb-4">({review.location})</p>
                <div className="flex justify-center mb-4">
                   {[...Array(5)].map((_, i) => (
                     <Star key={i} className={`w-4 h-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-600'}`} />
                   ))}
                </div>
                <p className="text-slate-300 text-sm italic leading-relaxed">
                  "{review.text}"
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;