import React from 'react';
import { Mic, KeyRound, History, Smartphone, Monitor } from 'lucide-react';

const MainFunctions: React.FC = () => {
  return (
    <section id="funciones" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-blue-900 sm:text-4xl">FUNCIONES PRINCIPALES</h2>
          <p className="mt-4 text-lg text-gray-600">Control total en la palma de tu mano</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {/* Audio */}
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:-translate-y-2 transition-transform duration-300">
            <div className="bg-purple-100 p-6 flex justify-center">
              <Mic className="w-16 h-16 text-purple-600" />
            </div>
            <div className="p-8">
              <h3 className="text-2xl font-bold text-purple-700 mb-4">Monitoreo de Audio</h3>
              <p className="text-gray-600">
                Escucha en tiempo real lo que sucede dentro de la cabina del vehículo. Ideal para seguridad y control de calidad en el servicio.
              </p>
            </div>
          </div>

          {/* Engine Block */}
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:-translate-y-2 transition-transform duration-300">
            <div className="bg-red-100 p-6 flex justify-center">
              <KeyRound className="w-16 h-16 text-red-600" />
            </div>
            <div className="p-8">
              <h3 className="text-2xl font-bold text-red-600 mb-4">Bloqueo de Motor</h3>
              <p className="text-gray-600">
                Apaga el vehículo desde tu celular al instante. Toma el control aunque otra persona tenga la llave física. Prevención total de robos.
              </p>
            </div>
          </div>

          {/* History */}
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:-translate-y-2 transition-transform duration-300">
            <div className="bg-blue-100 p-6 flex justify-center">
              <History className="w-16 h-16 text-blue-600" />
            </div>
            <div className="p-8">
              <h3 className="text-2xl font-bold text-blue-600 mb-4">Historial de Rutas</h3>
              <p className="text-gray-600">
                Visualización de ruta dibujada en el mapa. Información detallada de kilometraje, velocidad, tiempo de paradas y reproducción del recorrido.
              </p>
            </div>
          </div>
        </div>

        {/* App Platform Banner */}
        <div className="bg-slate-900 rounded-3xl p-8 md:p-12 text-white flex flex-col md:flex-row items-center gap-10 shadow-2xl">
            <div className="md:w-1/2 space-y-6">
                <h3 className="text-3xl font-bold text-teal-400">
                    APLICACIÓN Y PLATAFORMA DE SEGUIMIENTO
                </h3>
                <p className="text-lg text-slate-300 leading-relaxed">
                    Vea sus unidades de forma remota desde cualquier lugar. Nuestra plataforma es intuitiva, rápida y está disponible para todos sus dispositivos.
                </p>
                <ul className="space-y-3">
                    <li className="flex items-center gap-3">
                        <Smartphone className="text-blue-400" />
                        <span>App nativa para Android e iOS</span>
                    </li>
                    <li className="flex items-center gap-3">
                        <Monitor className="text-blue-400" />
                        <span>Plataforma Web para gestión de flotas</span>
                    </li>
                </ul>
            </div>
            <div className="md:w-1/2 flex justify-center">
                <img 
                    src="https://picsum.photos/500/300?random=2" 
                    alt="Plataforma GPS Dashboard" 
                    className="rounded-lg shadow-2xl border-4 border-slate-700 transform rotate-1 hover:rotate-0 transition-transform duration-500"
                />
            </div>
        </div>

      </div>
    </section>
  );
};

export default MainFunctions;